from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.db import IntegrityError
from .forms import *
from .models import User

# Create your views here.


def signUp(request):

    if request.method == 'GET':
        return render(request, './HTML/Signin.html', {
            'form': CreateNewUser
        })
    else:

        if request.POST['password1'] == request.POST['password2']:
            # Register user :)
            
            try:
                user = User.objects.create(id=request.POST['id'],
                                                password=request.POST['password1'])
                user.save()
                return redirect('home', user.id)
            except IntegrityError:
                return render(request, './HTML/Signin.html', {
                    'form': CreateNewUser,
                    'error': 'El usuario ya existe en la base de datos'
                })
        
        return render(request, './HTML/Signin.html', {
            'form': CreateNewUser,
            'error': 'Lo sentimos pero las contraseñas no coinciden'
        })


def home(request):
    return render(request, './HTML/HomePage.html', {

    })


def searchAnnouncement(request):
    if request.method == 'GET':
        return render(request, './HTML/SearchPage.html', {
            'form': Filter
        })
    else:
        print(request.POST['scolarshipId'])
        print(request.POST['type'])
        print(request.POST['deadline'])


def signout(request):
    logout(request)
    return redirect('home')


def signin(request):

    if request.method == 'GET':
        return render(request, './HTML/LoginPage.html', {
            'form': Login
        })
    else:
        user = User.objects.get(id=request.POST['id'])

        if user == None:
            return render(request, './HTML/LoginPage.html', {
                'form': Login,
                'error': 'El usuario no existe'
            })
        elif request.POST['password1']!=user.password:
            return render(request, './HTML/LoginPage.html', {
                'form': Login,
                'error': 'La contraseña es incorrecta'
            })
        else:
            return redirect('home')
        
        
