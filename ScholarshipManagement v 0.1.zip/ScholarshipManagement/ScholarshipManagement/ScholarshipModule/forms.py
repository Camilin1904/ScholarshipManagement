from django import forms

inputStyle = "width: 30%; border: 3px solid #DFDFDF; border-radius: 4px;"

class CreateNewUser(forms.Form):
    id = forms.CharField(label='Usuario', max_length=30, widget=forms.TextInput(attrs={"class":"input"}))
    password1 = forms.CharField(label='Contraseña', widget=forms.PasswordInput(attrs={"class":"input"}))
    password2 = forms.CharField(label='Confirmar Contraseña', widget=forms.PasswordInput(attrs={"class":"input"}))

class Login(forms.Form):
    id = forms.CharField(label='Usuario', max_length=30, widget=forms.TextInput(attrs={"class":"input"}))
    password1 = forms.CharField(label='Contraseña', widget=forms.PasswordInput(attrs={"class":"input"}))

class Filter(forms.Form):
    scolarshipId = forms.CharField(label='Id programa de beca', max_length=30, widget=forms.TextInput(
        attrs={"class":"input"}), required=False)
    CHOICES = [
    (1, "Abierta"),
    (2, "Cerrada"),
    (3, "Mixta"),
    (4, "Todas")
    ]
    type = forms.ChoiceField(label='Tipo de convocatoria', 
                             choices=CHOICES, widget=forms.Select(attrs={"class":"input"}), required=False)
    deadline = forms.DateField(label='Fecha limite', 
                               widget=forms.DateInput(attrs={"class":"input"}), required=False)